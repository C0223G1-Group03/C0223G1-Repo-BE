package com.example.customer.customer.repository;

public interface IEmployeeRepo {
}
