package com.example.customer.customer.service;

public interface IEmployeeService {
}
