package com.example.customer.customer.model;

public class Employee {
}
