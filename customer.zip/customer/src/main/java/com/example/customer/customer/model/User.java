package com.example.customer.customer.model;

public class User {
}
