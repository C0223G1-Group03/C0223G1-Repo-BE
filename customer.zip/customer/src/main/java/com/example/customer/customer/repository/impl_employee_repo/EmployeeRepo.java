package com.example.customer.customer.repository.impl_employee_repo;

public class EmployeeRepo {
}
